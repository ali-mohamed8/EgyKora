<footer class="bg-white sticky-footer" style="margin-bottom: 0;">
    <div class="container my-auto">
        <div class="text-center my-auto copyright"><span>©
                    <script>
                        document.write(new Date().getUTCFullYear())
                    </script>EgyKora</span></div>
    </div>
</footer>
