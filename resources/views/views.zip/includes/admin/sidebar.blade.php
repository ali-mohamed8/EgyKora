<div class="sidebar-wrapper">
    <div class="logo">
        <a href="#" class="simple-text logo-normal">
        </a>
    </div>
    <ul class="nav">
        <li>
            <a href="{{route('admin.leagues')}}">
                <i class="fas fa-arrow-alt-circle-left "></i>
                <p>الدوريات-الفرق </p>
            </a>
        </li>
        <li>
            <a href="{{route('admin.tbDays.View')}}">
                <i class="fas fa-arrow-alt-circle-left"></i>
                <p>الايام المجدولة</p>
            </a>
        </li>
        <li>
            <a href="{{route('admin.tables.setTodayView')}}">
                <i class="fas fa-arrow-alt-circle-left"></i>
                <p>تحديد جدول مباريات اليوم</p>
            </a>
        </li>
        <li>
            <a href="{{route('admin.tables.setYesterdayView')}}">
                <i class="fas fa-arrow-alt-circle-left"></i>
                <p>تحديد جدول مباريات امس</p>
            </a>
        </li>
        <li>
            <a href="{{route('admin.tables.setTomorrowView')}}">
                <i class="fas fa-arrow-alt-circle-left"></i>
                <p>تحديد جدول مباريات الغد</p>
            </a>
        </li>

    </ul>
</div>
