@extends('layouts.admin')
@section('page')
    <a class="navbar-brand" href="{{route('admin.index')}}">الرئيسية</a>

@endsection
@section('content')
    <div class="row">
        <div class="col-lg-4 text-right">
            <div class="card card-chart">
                <div class="card-header">
                    <h5 class="card-category">مباريات اليوم</h5>
                    <h3 id="today_mat" class="card-title text-danger" ><i class="tim-icons  text-primary"></i> 0</h3>
                </div>
            </div>
        </div>
        <div class="col-lg-4 text-right">
            <div class="card card-chart">
                <div class="card-header">
                    <h5 class="card-category">الدوريات</h5>
                    <h3 class="card-title text-danger"><i class="tim-icons  text-info"></i> 0</h3>
                </div>
            </div>
        </div>
        <div class="col-lg-4 text-right">
            <div class="card card-chart">
                <div class="card-header">
                    <h5 class="card-category">الفرق</h5>
                    <h3 class="card-title text-danger"><i class="tim-icons text-success"></i> 0</h3>
                </div>
            </div>
        </div>
    </div>

@endsection
@section('scripts')
    <script>
        function myStopFunction() {
            clearInterval(inter)
        }
        function reset(){
            if (i>=101){
                myStopFunction()
            }
        }
        var i = 0;
        var inter = setInterval(function(){
            $('#today_mat').text(i)
            ++i;
            reset();
            },50)



    </script>
@endsection
