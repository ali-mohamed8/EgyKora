@extends('layouts.site')
@section('tittle','جدول المباريات|ايجى كوره')
@section('tbMatch')
    <div class="container-fluid col-lg-9 col-md-12">
        <div class="col-12 text-dark ">
            <h3 class="text-dark mb-4" style=""> <a href="{{route('index.site')}}">الرئيسية</a>/ جدول المباريات</h3>
        </div>

        <div class="card shadow">
            <div class="card-header py-3">
                <p class="text-secondary text-center m-0 font-weight-bold" style="
                float:right;
                 right: 100px;
                 font-size: 30px;
                 font-family: 'Jomhuria', cursive;
                 color: #5b79f5;">
                    جدول المباريات</p>
                <div id="clock">

                </div>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-lg-12">
                        <ul class="nav nav-pills mb-3 col-lg-12 " id="pills-tab" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active"  id="pills-source1-tab" data-toggle="pill" href="#pills-source1" role="tab" aria-controls="pills-home" aria-selected="true">امس</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link"   id="pills-source2-tab" data-toggle="pill" href="#pills-source2" role="tab" aria-controls="pills-profile" aria-selected="false">اليوم</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link"   id="pills-source3-tab" data-toggle="pill" href="#pills-source3" role="tab" aria-controls="pills-contact" aria-selected="false">غدا</a>
                            </li>
                        </ul>
                        <div class="tab-content " id="pills-tabContent">
                            <div class="tab-pane fade show active col-12" id="pills-source1" role="tabpanel" aria-labelledby="pills-home-tab">
                                <div class="list-group matches">
                                    <a class="list-group-item" href="#"
                                       style="background: #e3e6f0;color: #eaecf4;  border-top-left-radius:25px;
                                    border-top-right-radius: 25px;">
                                        <div class="col-3" style="
                                float: left;
                                margin-left: auto;
                                border-right: 1px solid #45464e;
                                border-left: 1px solid #45464e;
                                height: 50px;
                           "></div>
                                        <div class="col-6 text-center" style="
                           height: 50px;
                           float: left;
                           "><p style="margin-top: 4%;color: black;">مباراه1</p></div>
                                        <div class="col-3" style="
                           border-left: 1px solid #45464e;
                           height: 50px;
                           border-right: 1px solid #45464e;
                           float: left;
                           "></div>
                                    </a>
                                    <br>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="pills-source2" role="tabpanel" aria-labelledby="pills-profile-tab">
                                <div class="list-group matches">
                                    <a class="list-group-item" href="#"
                                       style="background: #e3e6f0;color: #eaecf4;  border-top-left-radius:25px;
                                    border-top-right-radius: 25px;">
                                        <div class="col-3" style="
                                float: left;
                                margin-left: auto;
                                border-right: 1px solid #45464e;
                                border-left: 1px solid #45464e;
                                height: 50px;
                           "></div>
                                        <div class="col-6 text-center" style="
                           height: 50px;
                           float: left;
                           "><p style="margin-top: 4%;color: black;">مباراه1</p></div>
                                        <div class="col-3" style="
                           border-left: 1px solid #45464e;
                           height: 50px;
                           border-right: 1px solid #45464e;
                           float: left;
                           "></div>
                                    </a>
                                    <br>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="pills-source3" role="tabpanel" aria-labelledby="pills-contact-tab">
                                <div class="list-group matches">
                                    <a class="list-group-item" href="#"
                                       style="background: #e3e6f0;color: #eaecf4;  border-top-left-radius:25px;
                                    border-top-right-radius: 25px;">
                                        <div class="col-3" style="
                                float: left;
                                margin-left: auto;
                                border-right: 1px solid #45464e;
                                border-left: 1px solid #45464e;
                                height: 50px;
                           "></div>
                                        <div class="col-6 text-center" style="
                           height: 50px;
                           float: left;
                           "><p style="margin-top: 4%;color: black;">مباراه1</p></div>
                                        <div class="col-3" style="
                           border-left: 1px solid #45464e;
                           height: 50px;
                           border-right: 1px solid #45464e;
                           float: left;
                           "></div>
                                    </a>
                                    <br>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
@endsection





